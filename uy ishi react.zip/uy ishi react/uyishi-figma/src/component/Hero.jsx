import "./Hero.css"
const Hero = () => {
  return (
    <div className="hero">
        
    </div>
  )
}

export default Hero