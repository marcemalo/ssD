import "./Keyboard.css"

const Keyboard = () => {
  return (
    <div className="keyboard">
          <img src="./src/component/img/Call to Action.png" alt="" />
    </div>
  )
}

export default Keyboard