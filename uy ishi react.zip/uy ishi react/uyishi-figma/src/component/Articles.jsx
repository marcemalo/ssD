import "./Article.css"

const Articles = () => {
  return (
    <div className="Article">
         <div className="container">
            <div className="article_h1">
                <h1 className="article_hh">Featured articles</h1>
            </div>
            <div className="artice__wrapper">
                  <div className="article__card">
                    <div className="a_c_img">
                        <img src="./src/component/img/12px.png" alt="" />
                    </div>
                    <div className="a_c_text">
                        <h3  className="cc">10 beaches you must visit</h3>
                        <img className="cc" src="./src/component/img/Meta.png" alt="" />
                        <p className="cc">On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the…</p>
                    </div>
                  </div>


                  <div className="article__card">
                    <div className="a_c_img">
                        <img src="./src/component/img/12px.png" alt="" />
                    </div>
                    <div className="a_c_text">
                        <h3  className="cc">10 beaches you must visit</h3>
                        <img className="cc" src="./src/component/img/Meta.png" alt="" />
                        <p className="cc">On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the…</p>
                    </div>
                  </div>

                  <div className="article__card">
                    <div className="a_c_img">
                        <img src="./src/component/img/12px.png" alt="" />
                    </div>
                    <div className="a_c_text">
                        <h3  className="cc">10 beaches you must visit</h3>
                        <img className="cc" src="./src/component/img/Meta.png" alt="" />
                        <p className="cc">On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the…</p>
                    </div>
                  </div>

                  <div className="article__card">
                    <div className="a_c_img">
                        <img src="./src/component/img/12px.png" alt="" />
                    </div>
                    <div className="a_c_text">
                        <h3  className="cc">10 beaches you must visit</h3>
                        <img className="cc" src="./src/component/img/Meta.png" alt="" />
                        <p className="cc">On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the…</p>
                    </div>
                  </div>

                  <div className="article__card">
                    <div className="a_c_img">
                        <img src="./src/component/img/12px.png" alt="" />
                    </div>
                    <div className="a_c_text">
                        <h3  className="cc">10 beaches you must visit</h3>
                        <img className="cc" src="./src/component/img/Meta.png" alt="" />
                        <p className="cc">On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the…</p>
                    </div>
                  </div>

                  <div className="article__card">
                    <div className="a_c_img">
                        <img src="./src/component/img/12px.png" alt="" />
                    </div>
                    <div className="a_c_text">
                        <h3  className="cc">10 beaches you must visit</h3>
                        <img className="cc" src="./src/component/img/Meta.png" alt="" />
                        <p className="cc">On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the…</p>
                    </div>
                  </div>


                  

                  
            </div>
         </div>
    </div>
  )
}

export default Articles