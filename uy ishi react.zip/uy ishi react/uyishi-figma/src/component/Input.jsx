import "./Input.css"
const Input = () => {
  return (
    <div className="Input">
        <div className="container">
            <div className="biggi">
                <div className="kk">
                    <h1 className="bn">Incredible deals, right to your inbox!</h1>
                    <input className="ss" type="text" placeholder="PLACEHOLDER" />
                    <p className="zz">By joining you agree to our Terms and Conditions</p>
                </div>
            </div>
        </div>
    </div>
  )
}

export default Input