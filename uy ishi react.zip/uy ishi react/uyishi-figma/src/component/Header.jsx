import "./Header.css"

const Header = () => {
  return (
    <div className="nav">
        <div className="container">
            <div className="nav-wrapper">
                <div className="navimg1">
                    <img src="./src/component/img/Logo.png" alt="" />
                </div>
                <div>
                    <img src="./src/component/img/Frame 71.png" alt="" />
                </div>
            </div>
        </div>
    </div>
  )
}

export default Header