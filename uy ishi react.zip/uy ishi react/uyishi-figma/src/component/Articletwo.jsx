import "./Articletwo.css"

const Articletwo = () => {
  return (
     <div className="articl2">
        <div className="container">
            <div>
                <h1 className="ll">Featured articles</h1>
            </div>
            <div className="a______wrapper">


                <div className="a_cc">
                    <div className="aa__img">
                        <img src="./src/component/img/12px.svg" alt="" />
                    </div>
                    <div className="aa__tt">
                        <h1 className="cc">Pathway to the Mediterranean</h1>
                        <img className="cc" src="./src/component/img/Meta.png" alt="" />
                        <p className="cc">On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee the pain a…</p>
                    </div>
                </div>


                <div className="a_cc">
                    <div className="aa__img">
                        <img src="./src/component/img/12px.jpg" alt="" />
                    </div>
                    <div className="aa__tt">
                        <h1 className="cc">Pathway to the Mediterranean</h1>
                        <img className="cc" src="./src/component/img/Meta.png" alt="" />
                        <p className="cc">On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee the pain a…</p>
                    </div>
                </div>


                <div className="a_cc">
                    <div className="aa__img">
                        <img src="./src/component/img/12px.svg" alt="" />
                    </div>
                    <div className="aa__tt">
                        <h1 className="cc">Pathway to the Mediterranean</h1>
                        <img className="cc" src="./src/component/img/Meta.png" alt="" />
                        <p className="cc">On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee the pain a…</p>
                    </div>
                </div>


                <div className="a_cc">
                    <div className="aa__img">
                        <img src="./src/component/img/12px.jpg" alt="" />
                    </div>
                    <div className="aa__tt">
                        <h1 className="cc">Pathway to the Mediterranean</h1>
                        <img className="cc" src="./src/component/img/Meta.png" alt="" />
                        <p className="cc">On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee the pain a…</p>
                    </div>
                </div>


                <div className="a_cc">
                    <div className="aa__img">
                        <img src="./src/component/img/12px.svg" alt="" />
                    </div>
                    <div className="aa__tt">
                        <h1 className="cc">Pathway to the Mediterranean</h1>
                        <img className="cc" src="./src/component/img/Meta.png" alt="" />
                        <p className="cc">On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee the pain a…</p>
                    </div>
                </div>


                      <div className="btnart">
                        <button className="gh">Load more</button>
                      </div>
            </div>
        </div>
     </div>
  )
}

export default Articletwo