import './App.css'
import Header from './component/Header'
import Hero from './component/Hero'
import Articles from './component/Articles'
import Keyboard from './component/Keyboard'
import Articletwo from './component/Articletwo'
import Input from './component/Input'

function App() {
  return (
    <>
     {Header()}
     {Hero()}
     {Articles()}
     {Keyboard()}
     {Articletwo()}
     {Input()}
    </>
  )
}

export default App
